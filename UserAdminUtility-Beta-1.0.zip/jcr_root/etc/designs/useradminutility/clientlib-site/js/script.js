//TAB JS START
function openTab(evt, tabID) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the link that opened the tab
    document.getElementById(tabID).style.display = "block";
    evt.currentTarget.className += " active";
}
//TAB JS END
/*Checkbox JS Start*/
function getCheckedCheckboxesFor(checkboxName) {
    var checkboxes = document.querySelectorAll('input[name="' + checkboxName + '"]:checked'),
        values = [];
    Array.prototype.forEach.call(checkboxes, function(el) {
        values.push(el.value);
    });
    return values;
}

$('#showUsersforSelectedGroups').click(function() {
    $('#ShowUsersList tr').remove();
	$('#NoOfUsersSelectedGroups h3').remove();
    var tempList = '';
    tempList = getCheckedCheckboxesFor('groupsList');

    $.ajax({
        type: "GET",
        data: {
            tempList: tempList
        },
        url: "/bin/tools/listSelectedGroupsUsers",
        success: function(response) {
            var trHTML = '';
            $(jQuery.parseJSON(response)).each(function() {
                var principalName = this.principalName;
                var userUUID = this.userUUID;
                var groupName = this.groupName;
                trHTML += '<tr><td>' + principalName + '</td><td>' + userUUID + '</td><td>' + groupName + '</td></tr>';
            });
            $('#ShowUsersList').append("<tr><th>PrincipalName</th><th>UUID</th><th>GroupName</th></tr>" + trHTML);
            var usersLength = document.getElementById("ShowUsersList").rows.length;
			usersLength = usersLength -1;
            $('#NoOfUsersSelectedGroups').append('<h3>Number of records found: '+ usersLength +'</h3>');
        },
        error: function() {
            alert('Error occured in getting data');
        }
    });
});

$('#exportUsersSelectedGroups').click(function() {
    var tempList = '';
    tempList = getCheckedCheckboxesFor('groupsList');
    $.getJSON("/bin/tools/listSelectedGroupsUsers", {
        tempList: tempList
    }, function(data) {
        JSONToCSVConvertor(data, "Selected_All_Users", true);
    });
});

$('#getAllSystemUsers').click(function() {
    $.getJSON("/bin/querybuilder.json?path=/home/users&property=jcr:primaryType&property.value=rep:SystemUser&p.limit=-1", null, function(data) {
        console.log(data);
    });
});


/*Checkbox JS End*/
$(document).ready(function() {
    $.getJSON("/bin/tools/listGroups", null, function(data) {
        var temp = data;
        var options = '';
        var checkOptions = '';
        temp.map(function(val) {
            options += '<option value="' + val.groupID + '">' + val.group + '</option>';
            checkOptions += '<input name="groupsList" type="checkbox" value="' + val.groupID + '"/> <label for="groupsList">' + val.group + '</label>';
        });
        $('#GroupsList').append(options);
        $('#groupArray').append(checkOptions);
        $('#exportGroups').click(function() {
            JSONToCSVConvertor(temp, "ListOfGroups", true);
        });
    });
});
$('#GroupsList').change(function() {
    $('#UsersList tr').remove();
    $('#NoOfUsersSelectedGroup h3').remove();
    $('#exportUsers').attr('disabled', false);
    var data = "";
    $.ajax({
        type: "GET",
        url: "/bin/tools/listUsers",
        cache: false,
        data: "GroupList_ID=" + $(this).val(),
        success: function(response) {
            data = response;
            var trHTML = '';

            $(jQuery.parseJSON(response)).each(function() {
                var principalName = this.principalName;
                var userUUID = this.userUUID;
                trHTML += '<tr><td>' + principalName + '</td><td>' + userUUID + '</td></tr>';
            });
            $('#UsersList').append("<tr><th>PrincipalName</th><th>UUID</th></tr>" + trHTML);
    		var usersLength = document.getElementById("UsersList").rows.length;
			usersLength = usersLength -1;
            $('#NoOfUsersSelectedGroup').append('<h3>Number of records found: '+ usersLength +'</h3>');
        },
        error: function() {
            alert('Error occured in getting data.');
        }
    });
});

$('#exportUsers').click(function() {
    var selectedGroup = $("#GroupsList option:selected").text();
    var selectedGroupID = $('#GroupsList option:selected').val();
    $.getJSON("/bin/tools/listUsers", "GroupList_ID=" + selectedGroupID, function(data) {
        JSONToCSVConvertor(data, selectedGroup, true);
    });
});

function JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel) {

    //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
    var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;

    var CSV = '';

    //CSV += ReportTitle + '\r\n\n';

    if (ShowLabel) {
        var row = "";
        for (var index in arrData[0]) {
            row += index + ',';
        }

        row = row.slice(0, -1);

        //append Label row with line break
        CSV += row + '\r\n';
    }

    for (var i = 0; i < arrData.length; i++) {
        var row = "";

        for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
        }

        row.slice(0, row.length - 1);

        CSV += row + '\r\n';
    }

    if (CSV == '') {
        alert("Invalid data");
        return;
    }

    var fileName = "Group_";

    fileName += ReportTitle.replace(/ /g, "_");

    var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);

    var link = document.createElement("a");
    link.href = uri;

    link.style = "visibility:hidden";
    link.download = fileName + ".csv";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}